r"""Wrapper for modal_pipe_interfaces.h

Generated with:
/usr/local/bin/ctypesgen -I/ci_data/builds/iDWDkaXk/0/voxl-public/voxl-sdk/core-libs/libmodal-pipe/library/include /ci_data/builds/iDWDkaXk/0/voxl-public/voxl-sdk/core-libs/libmodal-pipe/library/include/modal_pipe_interfaces.h -o /ci_data/builds/iDWDkaXk/0/voxl-public/voxl-sdk/core-libs/libmodal-pipe/build64/python/pympa_types.py

Do not modify this file.
"""

__docformat__ = "restructuredtext"

# Begin preamble for Python

import ctypes
import sys
from ctypes import *  # noqa: F401, F403

_int_types = (ctypes.c_int16, ctypes.c_int32)
if hasattr(ctypes, "c_int64"):
    # Some builds of ctypes apparently do not have ctypes.c_int64
    # defined; it's a pretty good bet that these builds do not
    # have 64-bit pointers.
    _int_types += (ctypes.c_int64,)
for t in _int_types:
    if ctypes.sizeof(t) == ctypes.sizeof(ctypes.c_size_t):
        c_ptrdiff_t = t
del t
del _int_types



class UserString:
    def __init__(self, seq):
        if isinstance(seq, bytes):
            self.data = seq
        elif isinstance(seq, UserString):
            self.data = seq.data[:]
        else:
            self.data = str(seq).encode()

    def __bytes__(self):
        return self.data

    def __str__(self):
        return self.data.decode()

    def __repr__(self):
        return repr(self.data)

    def __int__(self):
        return int(self.data.decode())

    def __long__(self):
        return int(self.data.decode())

    def __float__(self):
        return float(self.data.decode())

    def __complex__(self):
        return complex(self.data.decode())

    def __hash__(self):
        return hash(self.data)

    def __le__(self, string):
        if isinstance(string, UserString):
            return self.data <= string.data
        else:
            return self.data <= string

    def __lt__(self, string):
        if isinstance(string, UserString):
            return self.data < string.data
        else:
            return self.data < string

    def __ge__(self, string):
        if isinstance(string, UserString):
            return self.data >= string.data
        else:
            return self.data >= string

    def __gt__(self, string):
        if isinstance(string, UserString):
            return self.data > string.data
        else:
            return self.data > string

    def __eq__(self, string):
        if isinstance(string, UserString):
            return self.data == string.data
        else:
            return self.data == string

    def __ne__(self, string):
        if isinstance(string, UserString):
            return self.data != string.data
        else:
            return self.data != string

    def __contains__(self, char):
        return char in self.data

    def __len__(self):
        return len(self.data)

    def __getitem__(self, index):
        return self.__class__(self.data[index])

    def __getslice__(self, start, end):
        start = max(start, 0)
        end = max(end, 0)
        return self.__class__(self.data[start:end])

    def __add__(self, other):
        if isinstance(other, UserString):
            return self.__class__(self.data + other.data)
        elif isinstance(other, bytes):
            return self.__class__(self.data + other)
        else:
            return self.__class__(self.data + str(other).encode())

    def __radd__(self, other):
        if isinstance(other, bytes):
            return self.__class__(other + self.data)
        else:
            return self.__class__(str(other).encode() + self.data)

    def __mul__(self, n):
        return self.__class__(self.data * n)

    __rmul__ = __mul__

    def __mod__(self, args):
        return self.__class__(self.data % args)

    # the following methods are defined in alphabetical order:
    def capitalize(self):
        return self.__class__(self.data.capitalize())

    def center(self, width, *args):
        return self.__class__(self.data.center(width, *args))

    def count(self, sub, start=0, end=sys.maxsize):
        return self.data.count(sub, start, end)

    def decode(self, encoding=None, errors=None):  # XXX improve this?
        if encoding:
            if errors:
                return self.__class__(self.data.decode(encoding, errors))
            else:
                return self.__class__(self.data.decode(encoding))
        else:
            return self.__class__(self.data.decode())

    def encode(self, encoding=None, errors=None):  # XXX improve this?
        if encoding:
            if errors:
                return self.__class__(self.data.encode(encoding, errors))
            else:
                return self.__class__(self.data.encode(encoding))
        else:
            return self.__class__(self.data.encode())

    def endswith(self, suffix, start=0, end=sys.maxsize):
        return self.data.endswith(suffix, start, end)

    def expandtabs(self, tabsize=8):
        return self.__class__(self.data.expandtabs(tabsize))

    def find(self, sub, start=0, end=sys.maxsize):
        return self.data.find(sub, start, end)

    def index(self, sub, start=0, end=sys.maxsize):
        return self.data.index(sub, start, end)

    def isalpha(self):
        return self.data.isalpha()

    def isalnum(self):
        return self.data.isalnum()

    def isdecimal(self):
        return self.data.isdecimal()

    def isdigit(self):
        return self.data.isdigit()

    def islower(self):
        return self.data.islower()

    def isnumeric(self):
        return self.data.isnumeric()

    def isspace(self):
        return self.data.isspace()

    def istitle(self):
        return self.data.istitle()

    def isupper(self):
        return self.data.isupper()

    def join(self, seq):
        return self.data.join(seq)

    def ljust(self, width, *args):
        return self.__class__(self.data.ljust(width, *args))

    def lower(self):
        return self.__class__(self.data.lower())

    def lstrip(self, chars=None):
        return self.__class__(self.data.lstrip(chars))

    def partition(self, sep):
        return self.data.partition(sep)

    def replace(self, old, new, maxsplit=-1):
        return self.__class__(self.data.replace(old, new, maxsplit))

    def rfind(self, sub, start=0, end=sys.maxsize):
        return self.data.rfind(sub, start, end)

    def rindex(self, sub, start=0, end=sys.maxsize):
        return self.data.rindex(sub, start, end)

    def rjust(self, width, *args):
        return self.__class__(self.data.rjust(width, *args))

    def rpartition(self, sep):
        return self.data.rpartition(sep)

    def rstrip(self, chars=None):
        return self.__class__(self.data.rstrip(chars))

    def split(self, sep=None, maxsplit=-1):
        return self.data.split(sep, maxsplit)

    def rsplit(self, sep=None, maxsplit=-1):
        return self.data.rsplit(sep, maxsplit)

    def splitlines(self, keepends=0):
        return self.data.splitlines(keepends)

    def startswith(self, prefix, start=0, end=sys.maxsize):
        return self.data.startswith(prefix, start, end)

    def strip(self, chars=None):
        return self.__class__(self.data.strip(chars))

    def swapcase(self):
        return self.__class__(self.data.swapcase())

    def title(self):
        return self.__class__(self.data.title())

    def translate(self, *args):
        return self.__class__(self.data.translate(*args))

    def upper(self):
        return self.__class__(self.data.upper())

    def zfill(self, width):
        return self.__class__(self.data.zfill(width))


class MutableString(UserString):
    """mutable string objects

    Python strings are immutable objects.  This has the advantage, that
    strings may be used as dictionary keys.  If this property isn't needed
    and you insist on changing string values in place instead, you may cheat
    and use MutableString.

    But the purpose of this class is an educational one: to prevent
    people from inventing their own mutable string class derived
    from UserString and than forget thereby to remove (override) the
    __hash__ method inherited from UserString.  This would lead to
    errors that would be very hard to track down.

    A faster and better solution is to rewrite your program using lists."""

    def __init__(self, string=""):
        self.data = string

    def __hash__(self):
        raise TypeError("unhashable type (it is mutable)")

    def __setitem__(self, index, sub):
        if index < 0:
            index += len(self.data)
        if index < 0 or index >= len(self.data):
            raise IndexError
        self.data = self.data[:index] + sub + self.data[index + 1 :]

    def __delitem__(self, index):
        if index < 0:
            index += len(self.data)
        if index < 0 or index >= len(self.data):
            raise IndexError
        self.data = self.data[:index] + self.data[index + 1 :]

    def __setslice__(self, start, end, sub):
        start = max(start, 0)
        end = max(end, 0)
        if isinstance(sub, UserString):
            self.data = self.data[:start] + sub.data + self.data[end:]
        elif isinstance(sub, bytes):
            self.data = self.data[:start] + sub + self.data[end:]
        else:
            self.data = self.data[:start] + str(sub).encode() + self.data[end:]

    def __delslice__(self, start, end):
        start = max(start, 0)
        end = max(end, 0)
        self.data = self.data[:start] + self.data[end:]

    def immutable(self):
        return UserString(self.data)

    def __iadd__(self, other):
        if isinstance(other, UserString):
            self.data += other.data
        elif isinstance(other, bytes):
            self.data += other
        else:
            self.data += str(other).encode()
        return self

    def __imul__(self, n):
        self.data *= n
        return self


class String(MutableString, ctypes.Union):

    _fields_ = [("raw", ctypes.POINTER(ctypes.c_char)), ("data", ctypes.c_char_p)]

    def __init__(self, obj=b""):
        if isinstance(obj, (bytes, UserString)):
            self.data = bytes(obj)
        else:
            self.raw = obj

    def __len__(self):
        return self.data and len(self.data) or 0

    def from_param(cls, obj):
        # Convert None or 0
        if obj is None or obj == 0:
            return cls(ctypes.POINTER(ctypes.c_char)())

        # Convert from String
        elif isinstance(obj, String):
            return obj

        # Convert from bytes
        elif isinstance(obj, bytes):
            return cls(obj)

        # Convert from str
        elif isinstance(obj, str):
            return cls(obj.encode())

        # Convert from c_char_p
        elif isinstance(obj, ctypes.c_char_p):
            return obj

        # Convert from POINTER(ctypes.c_char)
        elif isinstance(obj, ctypes.POINTER(ctypes.c_char)):
            return obj

        # Convert from raw pointer
        elif isinstance(obj, int):
            return cls(ctypes.cast(obj, ctypes.POINTER(ctypes.c_char)))

        # Convert from ctypes.c_char array
        elif isinstance(obj, ctypes.c_char * len(obj)):
            return obj

        # Convert from object
        else:
            return String.from_param(obj._as_parameter_)

    from_param = classmethod(from_param)


def ReturnString(obj, func=None, arguments=None):
    return String.from_param(obj)


# As of ctypes 1.0, ctypes does not support custom error-checking
# functions on callbacks, nor does it support custom datatypes on
# callbacks, so we must ensure that all callbacks return
# primitive datatypes.
#
# Non-primitive return values wrapped with UNCHECKED won't be
# typechecked, and will be converted to ctypes.c_void_p.
def UNCHECKED(type):
    if hasattr(type, "_type_") and isinstance(type._type_, str) and type._type_ != "P":
        return type
    else:
        return ctypes.c_void_p


# ctypes doesn't have direct support for variadic functions, so we have to write
# our own wrapper class
class _variadic_function(object):
    def __init__(self, func, restype, argtypes, errcheck):
        self.func = func
        self.func.restype = restype
        self.argtypes = argtypes
        if errcheck:
            self.func.errcheck = errcheck

    def _as_parameter_(self):
        # So we can pass this variadic function as a function pointer
        return self.func

    def __call__(self, *args):
        fixed_args = []
        i = 0
        for argtype in self.argtypes:
            # Typecheck what we can
            fixed_args.append(argtype.from_param(args[i]))
            i += 1
        return self.func(*fixed_args + list(args[i:]))


def ord_if_char(value):
    """
    Simple helper used for casts to simple builtin types:  if the argument is a
    string type, it will be converted to it's ordinal value.

    This function will raise an exception if the argument is string with more
    than one characters.
    """
    return ord(value) if (isinstance(value, bytes) or isinstance(value, str)) else value

# End preamble

_libs = {}
_libdirs = []

# Begin loader

"""
Load libraries - appropriately for all our supported platforms
"""
# ----------------------------------------------------------------------------
# Copyright (c) 2008 David James
# Copyright (c) 2006-2008 Alex Holkner
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions
# are met:
#
#  * Redistributions of source code must retain the above copyright
#    notice, this list of conditions and the following disclaimer.
#  * Redistributions in binary form must reproduce the above copyright
#    notice, this list of conditions and the following disclaimer in
#    the documentation and/or other materials provided with the
#    distribution.
#  * Neither the name of pyglet nor the names of its
#    contributors may be used to endorse or promote products
#    derived from this software without specific prior written
#    permission.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
# FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
# COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
# INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
# BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
# LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
# ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
# POSSIBILITY OF SUCH DAMAGE.
# ----------------------------------------------------------------------------

import ctypes
import ctypes.util
import glob
import os.path
import platform
import re
import sys


def _environ_path(name):
    """Split an environment variable into a path-like list elements"""
    if name in os.environ:
        return os.environ[name].split(":")
    return []


class LibraryLoader:
    """
    A base class For loading of libraries ;-)
    Subclasses load libraries for specific platforms.
    """

    # library names formatted specifically for platforms
    name_formats = ["%s"]

    class Lookup:
        """Looking up calling conventions for a platform"""

        mode = ctypes.DEFAULT_MODE

        def __init__(self, path):
            super(LibraryLoader.Lookup, self).__init__()
            self.access = dict(cdecl=ctypes.CDLL(path, self.mode))

        def get(self, name, calling_convention="cdecl"):
            """Return the given name according to the selected calling convention"""
            if calling_convention not in self.access:
                raise LookupError(
                    "Unknown calling convention '{}' for function '{}'".format(
                        calling_convention, name
                    )
                )
            return getattr(self.access[calling_convention], name)

        def has(self, name, calling_convention="cdecl"):
            """Return True if this given calling convention finds the given 'name'"""
            if calling_convention not in self.access:
                return False
            return hasattr(self.access[calling_convention], name)

        def __getattr__(self, name):
            return getattr(self.access["cdecl"], name)

    def __init__(self):
        self.other_dirs = []

    def __call__(self, libname):
        """Given the name of a library, load it."""
        paths = self.getpaths(libname)

        for path in paths:
            # noinspection PyBroadException
            try:
                return self.Lookup(path)
            except Exception:  # pylint: disable=broad-except
                pass

        raise ImportError("Could not load %s." % libname)

    def getpaths(self, libname):
        """Return a list of paths where the library might be found."""
        if os.path.isabs(libname):
            yield libname
        else:
            # search through a prioritized series of locations for the library

            # we first search any specific directories identified by user
            for dir_i in self.other_dirs:
                for fmt in self.name_formats:
                    # dir_i should be absolute already
                    yield os.path.join(dir_i, fmt % libname)

            # check if this code is even stored in a physical file
            try:
                this_file = __file__
            except NameError:
                this_file = None

            # then we search the directory where the generated python interface is stored
            if this_file is not None:
                for fmt in self.name_formats:
                    yield os.path.abspath(os.path.join(os.path.dirname(__file__), fmt % libname))

            # now, use the ctypes tools to try to find the library
            for fmt in self.name_formats:
                path = ctypes.util.find_library(fmt % libname)
                if path:
                    yield path

            # then we search all paths identified as platform-specific lib paths
            for path in self.getplatformpaths(libname):
                yield path

            # Finally, we'll try the users current working directory
            for fmt in self.name_formats:
                yield os.path.abspath(os.path.join(os.path.curdir, fmt % libname))

    def getplatformpaths(self, _libname):  # pylint: disable=no-self-use
        """Return all the library paths available in this platform"""
        return []


# Darwin (Mac OS X)


class DarwinLibraryLoader(LibraryLoader):
    """Library loader for MacOS"""

    name_formats = [
        "lib%s.dylib",
        "lib%s.so",
        "lib%s.bundle",
        "%s.dylib",
        "%s.so",
        "%s.bundle",
        "%s",
    ]

    class Lookup(LibraryLoader.Lookup):
        """
        Looking up library files for this platform (Darwin aka MacOS)
        """

        # Darwin requires dlopen to be called with mode RTLD_GLOBAL instead
        # of the default RTLD_LOCAL.  Without this, you end up with
        # libraries not being loadable, resulting in "Symbol not found"
        # errors
        mode = ctypes.RTLD_GLOBAL

    def getplatformpaths(self, libname):
        if os.path.pathsep in libname:
            names = [libname]
        else:
            names = [fmt % libname for fmt in self.name_formats]

        for directory in self.getdirs(libname):
            for name in names:
                yield os.path.join(directory, name)

    @staticmethod
    def getdirs(libname):
        """Implements the dylib search as specified in Apple documentation:

        http://developer.apple.com/documentation/DeveloperTools/Conceptual/
            DynamicLibraries/Articles/DynamicLibraryUsageGuidelines.html

        Before commencing the standard search, the method first checks
        the bundle's ``Frameworks`` directory if the application is running
        within a bundle (OS X .app).
        """

        dyld_fallback_library_path = _environ_path("DYLD_FALLBACK_LIBRARY_PATH")
        if not dyld_fallback_library_path:
            dyld_fallback_library_path = [
                os.path.expanduser("~/lib"),
                "/usr/local/lib",
                "/usr/lib",
            ]

        dirs = []

        if "/" in libname:
            dirs.extend(_environ_path("DYLD_LIBRARY_PATH"))
        else:
            dirs.extend(_environ_path("LD_LIBRARY_PATH"))
            dirs.extend(_environ_path("DYLD_LIBRARY_PATH"))
            dirs.extend(_environ_path("LD_RUN_PATH"))

        if hasattr(sys, "frozen") and getattr(sys, "frozen") == "macosx_app":
            dirs.append(os.path.join(os.environ["RESOURCEPATH"], "..", "Frameworks"))

        dirs.extend(dyld_fallback_library_path)

        return dirs


# Posix


class PosixLibraryLoader(LibraryLoader):
    """Library loader for POSIX-like systems (including Linux)"""

    _ld_so_cache = None

    _include = re.compile(r"^\s*include\s+(?P<pattern>.*)")

    name_formats = ["lib%s.so", "%s.so", "%s"]

    class _Directories(dict):
        """Deal with directories"""

        def __init__(self):
            dict.__init__(self)
            self.order = 0

        def add(self, directory):
            """Add a directory to our current set of directories"""
            if len(directory) > 1:
                directory = directory.rstrip(os.path.sep)
            # only adds and updates order if exists and not already in set
            if not os.path.exists(directory):
                return
            order = self.setdefault(directory, self.order)
            if order == self.order:
                self.order += 1

        def extend(self, directories):
            """Add a list of directories to our set"""
            for a_dir in directories:
                self.add(a_dir)

        def ordered(self):
            """Sort the list of directories"""
            return (i[0] for i in sorted(self.items(), key=lambda d: d[1]))

    def _get_ld_so_conf_dirs(self, conf, dirs):
        """
        Recursive function to help parse all ld.so.conf files, including proper
        handling of the `include` directive.
        """

        try:
            with open(conf) as fileobj:
                for dirname in fileobj:
                    dirname = dirname.strip()
                    if not dirname:
                        continue

                    match = self._include.match(dirname)
                    if not match:
                        dirs.add(dirname)
                    else:
                        for dir2 in glob.glob(match.group("pattern")):
                            self._get_ld_so_conf_dirs(dir2, dirs)
        except IOError:
            pass

    def _create_ld_so_cache(self):
        # Recreate search path followed by ld.so.  This is going to be
        # slow to build, and incorrect (ld.so uses ld.so.cache, which may
        # not be up-to-date).  Used only as fallback for distros without
        # /sbin/ldconfig.
        #
        # We assume the DT_RPATH and DT_RUNPATH binary sections are omitted.

        directories = self._Directories()
        for name in (
            "LD_LIBRARY_PATH",
            "SHLIB_PATH",  # HP-UX
            "LIBPATH",  # OS/2, AIX
            "LIBRARY_PATH",  # BE/OS
        ):
            if name in os.environ:
                directories.extend(os.environ[name].split(os.pathsep))

        self._get_ld_so_conf_dirs("/etc/ld.so.conf", directories)

        bitage = platform.architecture()[0]

        unix_lib_dirs_list = []
        if bitage.startswith("64"):
            # prefer 64 bit if that is our arch
            unix_lib_dirs_list += ["/lib64", "/usr/lib64"]

        # must include standard libs, since those paths are also used by 64 bit
        # installs
        unix_lib_dirs_list += ["/lib", "/usr/lib"]
        if sys.platform.startswith("linux"):
            # Try and support multiarch work in Ubuntu
            # https://wiki.ubuntu.com/MultiarchSpec
            if bitage.startswith("32"):
                # Assume Intel/AMD x86 compat
                unix_lib_dirs_list += ["/lib/i386-linux-gnu", "/usr/lib/i386-linux-gnu"]
            elif bitage.startswith("64"):
                # Assume Intel/AMD x86 compatible
                unix_lib_dirs_list += [
                    "/lib/x86_64-linux-gnu",
                    "/usr/lib/x86_64-linux-gnu",
                ]
            else:
                # guess...
                unix_lib_dirs_list += glob.glob("/lib/*linux-gnu")
        directories.extend(unix_lib_dirs_list)

        cache = {}
        lib_re = re.compile(r"lib(.*)\.s[ol]")
        # ext_re = re.compile(r"\.s[ol]$")
        for our_dir in directories.ordered():
            try:
                for path in glob.glob("%s/*.s[ol]*" % our_dir):
                    file = os.path.basename(path)

                    # Index by filename
                    cache_i = cache.setdefault(file, set())
                    cache_i.add(path)

                    # Index by library name
                    match = lib_re.match(file)
                    if match:
                        library = match.group(1)
                        cache_i = cache.setdefault(library, set())
                        cache_i.add(path)
            except OSError:
                pass

        self._ld_so_cache = cache

    def getplatformpaths(self, libname):
        if self._ld_so_cache is None:
            self._create_ld_so_cache()

        result = self._ld_so_cache.get(libname, set())
        for i in result:
            # we iterate through all found paths for library, since we may have
            # actually found multiple architectures or other library types that
            # may not load
            yield i


# Windows


class WindowsLibraryLoader(LibraryLoader):
    """Library loader for Microsoft Windows"""

    name_formats = ["%s.dll", "lib%s.dll", "%slib.dll", "%s"]

    class Lookup(LibraryLoader.Lookup):
        """Lookup class for Windows libraries..."""

        def __init__(self, path):
            super(WindowsLibraryLoader.Lookup, self).__init__(path)
            self.access["stdcall"] = ctypes.windll.LoadLibrary(path)


# Platform switching

# If your value of sys.platform does not appear in this dict, please contact
# the Ctypesgen maintainers.

loaderclass = {
    "darwin": DarwinLibraryLoader,
    "cygwin": WindowsLibraryLoader,
    "win32": WindowsLibraryLoader,
    "msys": WindowsLibraryLoader,
}

load_library = loaderclass.get(sys.platform, PosixLibraryLoader)()


def add_library_search_dirs(other_dirs):
    """
    Add libraries to search paths.
    If library paths are relative, convert them to absolute with respect to this
    file's directory
    """
    for path in other_dirs:
        if not os.path.isabs(path):
            path = os.path.abspath(path)
        load_library.other_dirs.append(path)


del loaderclass

# End loader

add_library_search_dirs([])

# No libraries

# No modules

__uint8_t = c_ubyte# /usr/include/x86_64-linux-gnu/bits/types.h: 38

__uint16_t = c_ushort# /usr/include/x86_64-linux-gnu/bits/types.h: 40

__uint32_t = c_uint# /usr/include/x86_64-linux-gnu/bits/types.h: 42

__uint64_t = c_ulong# /usr/include/x86_64-linux-gnu/bits/types.h: 45

uint8_t = __uint8_t# /usr/include/x86_64-linux-gnu/bits/stdint-uintn.h: 24

uint16_t = __uint16_t# /usr/include/x86_64-linux-gnu/bits/stdint-uintn.h: 25

uint32_t = __uint32_t# /usr/include/x86_64-linux-gnu/bits/stdint-uintn.h: 26

uint64_t = __uint64_t# /usr/include/x86_64-linux-gnu/bits/stdint-uintn.h: 27

# /ci_data/builds/iDWDkaXk/0/voxl-public/voxl-sdk/core-libs/libmodal-pipe/library/include/modal_pipe_interfaces.h: 100
class struct_tag_detection_t(Structure):
    pass

struct_tag_detection_t._pack_ = 1
struct_tag_detection_t.__slots__ = [
    'magic_number',
    'id',
    'size_m',
    'timestamp_ns',
    'name',
    'loc_type',
    'T_tag_wrt_cam',
    'R_tag_to_cam',
    'T_tag_wrt_fixed',
    'R_tag_to_fixed',
    'cam',
    'reserved',
]
struct_tag_detection_t._fields_ = [
    ('magic_number', uint32_t),
    ('id', c_int32),
    ('size_m', c_float),
    ('timestamp_ns', c_int64),
    ('name', c_char * int(64)),
    ('loc_type', c_int),
    ('T_tag_wrt_cam', c_float * int(3)),
    ('R_tag_to_cam', (c_float * int(3)) * int(3)),
    ('T_tag_wrt_fixed', c_float * int(3)),
    ('R_tag_to_fixed', (c_float * int(3)) * int(3)),
    ('cam', c_char * int(64)),
    ('reserved', c_int),
]

tag_detection_t = struct_tag_detection_t# /ci_data/builds/iDWDkaXk/0/voxl-public/voxl-sdk/core-libs/libmodal-pipe/library/include/modal_pipe_interfaces.h: 100

# /ci_data/builds/iDWDkaXk/0/voxl-public/voxl-sdk/core-libs/libmodal-pipe/library/include/modal_pipe_interfaces.h: 147
for _lib in _libs.values():
    if not _lib.has("pipe_validate_tag_detection_t", "cdecl"):
        continue
    pipe_validate_tag_detection_t = _lib.get("pipe_validate_tag_detection_t", "cdecl")
    pipe_validate_tag_detection_t.argtypes = [String, c_int, POINTER(c_int)]
    pipe_validate_tag_detection_t.restype = POINTER(tag_detection_t)
    break

# /ci_data/builds/iDWDkaXk/0/voxl-public/voxl-sdk/core-libs/libmodal-pipe/library/include/modal_pipe_interfaces.h: 159
for _lib in _libs.values():
    if not _lib.has("pipe_tag_location_type_to_string", "cdecl"):
        continue
    pipe_tag_location_type_to_string = _lib.get("pipe_tag_location_type_to_string", "cdecl")
    pipe_tag_location_type_to_string.argtypes = [c_int]
    pipe_tag_location_type_to_string.restype = c_char_p
    break

# /ci_data/builds/iDWDkaXk/0/voxl-public/voxl-sdk/core-libs/libmodal-pipe/library/include/modal_pipe_interfaces.h: 216
class struct_camera_image_metadata_t(Structure):
    pass

struct_camera_image_metadata_t._pack_ = 1
struct_camera_image_metadata_t.__slots__ = [
    'magic_number',
    'timestamp_ns',
    'frame_id',
    'width',
    'height',
    'size_bytes',
    'stride',
    'exposure_ns',
    'gain',
    'format',
    'framerate',
    'reserved',
]
struct_camera_image_metadata_t._fields_ = [
    ('magic_number', uint32_t),
    ('timestamp_ns', c_int64),
    ('frame_id', c_int32),
    ('width', c_int16),
    ('height', c_int16),
    ('size_bytes', c_int32),
    ('stride', c_int32),
    ('exposure_ns', c_int32),
    ('gain', c_int16),
    ('format', c_int16),
    ('framerate', c_int16),
    ('reserved', c_int16),
]

camera_image_metadata_t = struct_camera_image_metadata_t# /ci_data/builds/iDWDkaXk/0/voxl-public/voxl-sdk/core-libs/libmodal-pipe/library/include/modal_pipe_interfaces.h: 216

# /ci_data/builds/iDWDkaXk/0/voxl-public/voxl-sdk/core-libs/libmodal-pipe/library/include/modal_pipe_interfaces.h: 228
for _lib in _libs.values():
    if not _lib.has("pipe_image_format_to_string", "cdecl"):
        continue
    pipe_image_format_to_string = _lib.get("pipe_image_format_to_string", "cdecl")
    pipe_image_format_to_string.argtypes = [c_int]
    pipe_image_format_to_string.restype = c_char_p
    break

# /ci_data/builds/iDWDkaXk/0/voxl-public/voxl-sdk/core-libs/libmodal-pipe/library/include/modal_pipe_interfaces.h: 311
class struct_tof_data_t(Structure):
    pass

struct_tof_data_t._pack_ = 1
struct_tof_data_t.__slots__ = [
    'magic_number',
    'timestamp_ns',
    'points',
    'noises',
    'grayValues',
    'confidences',
]
struct_tof_data_t._fields_ = [
    ('magic_number', uint32_t),
    ('timestamp_ns', c_int64),
    ('points', (c_float * int(3)) * int((224 * 172))),
    ('noises', c_float * int((224 * 172))),
    ('grayValues', uint8_t * int((224 * 172))),
    ('confidences', uint8_t * int((224 * 172))),
]

tof_data_t = struct_tof_data_t# /ci_data/builds/iDWDkaXk/0/voxl-public/voxl-sdk/core-libs/libmodal-pipe/library/include/modal_pipe_interfaces.h: 311

# /ci_data/builds/iDWDkaXk/0/voxl-public/voxl-sdk/core-libs/libmodal-pipe/library/include/modal_pipe_interfaces.h: 359
for _lib in _libs.values():
    if not _lib.has("pipe_validate_tof_data_t", "cdecl"):
        continue
    pipe_validate_tof_data_t = _lib.get("pipe_validate_tof_data_t", "cdecl")
    pipe_validate_tof_data_t.argtypes = [String, c_int, POINTER(c_int)]
    pipe_validate_tof_data_t.restype = POINTER(tof_data_t)
    break

# /ci_data/builds/iDWDkaXk/0/voxl-public/voxl-sdk/core-libs/libmodal-pipe/library/include/modal_pipe_interfaces.h: 400
class struct_tof2_data_t(Structure):
    pass

struct_tof2_data_t._pack_ = 1
struct_tof2_data_t.__slots__ = [
    'magic_number',
    'timestamp_ns',
    'width',
    'height',
    'reserved1',
    'reserved2',
    'points',
    'noises',
    'grayValues',
    'confidences',
]
struct_tof2_data_t._fields_ = [
    ('magic_number', uint32_t),
    ('timestamp_ns', c_int64),
    ('width', c_int16),
    ('height', c_int16),
    ('reserved1', c_int16),
    ('reserved2', c_int16),
    ('points', (c_float * int(3)) * int((240 * 180))),
    ('noises', c_float * int((240 * 180))),
    ('grayValues', uint8_t * int((240 * 180))),
    ('confidences', uint8_t * int((240 * 180))),
]

tof2_data_t = struct_tof2_data_t# /ci_data/builds/iDWDkaXk/0/voxl-public/voxl-sdk/core-libs/libmodal-pipe/library/include/modal_pipe_interfaces.h: 400

# /ci_data/builds/iDWDkaXk/0/voxl-public/voxl-sdk/core-libs/libmodal-pipe/library/include/modal_pipe_interfaces.h: 447
for _lib in _libs.values():
    if not _lib.has("pipe_validate_tof2_data_t", "cdecl"):
        continue
    pipe_validate_tof2_data_t = _lib.get("pipe_validate_tof2_data_t", "cdecl")
    pipe_validate_tof2_data_t.argtypes = [String, c_int, POINTER(c_int)]
    pipe_validate_tof2_data_t.restype = POINTER(tof2_data_t)
    break

# /ci_data/builds/iDWDkaXk/0/voxl-public/voxl-sdk/core-libs/libmodal-pipe/library/include/modal_pipe_interfaces.h: 484
class struct_imu_data_t(Structure):
    pass

struct_imu_data_t._pack_ = 1
struct_imu_data_t.__slots__ = [
    'magic_number',
    'accl_ms2',
    'gyro_rad',
    'temp_c',
    'timestamp_ns',
]
struct_imu_data_t._fields_ = [
    ('magic_number', uint32_t),
    ('accl_ms2', c_float * int(3)),
    ('gyro_rad', c_float * int(3)),
    ('temp_c', c_float),
    ('timestamp_ns', uint64_t),
]

imu_data_t = struct_imu_data_t# /ci_data/builds/iDWDkaXk/0/voxl-public/voxl-sdk/core-libs/libmodal-pipe/library/include/modal_pipe_interfaces.h: 484

# /ci_data/builds/iDWDkaXk/0/voxl-public/voxl-sdk/core-libs/libmodal-pipe/library/include/modal_pipe_interfaces.h: 533
for _lib in _libs.values():
    if not _lib.has("pipe_validate_imu_data_t", "cdecl"):
        continue
    pipe_validate_imu_data_t = _lib.get("pipe_validate_imu_data_t", "cdecl")
    pipe_validate_imu_data_t.argtypes = [String, c_int, POINTER(c_int)]
    pipe_validate_imu_data_t.restype = POINTER(imu_data_t)
    break

# /ci_data/builds/iDWDkaXk/0/voxl-public/voxl-sdk/core-libs/libmodal-pipe/library/include/modal_pipe_interfaces.h: 582
class struct_point_cloud_metadata_t(Structure):
    pass

struct_point_cloud_metadata_t._pack_ = 1
struct_point_cloud_metadata_t.__slots__ = [
    'magic_number',
    'timestamp_ns',
    'n_points',
    'format',
    'id',
    'server_name',
    'reserved',
]
struct_point_cloud_metadata_t._fields_ = [
    ('magic_number', uint32_t),
    ('timestamp_ns', c_int64),
    ('n_points', uint32_t),
    ('format', uint32_t),
    ('id', uint32_t),
    ('server_name', c_char * int(32)),
    ('reserved', uint32_t),
]

point_cloud_metadata_t = struct_point_cloud_metadata_t# /ci_data/builds/iDWDkaXk/0/voxl-public/voxl-sdk/core-libs/libmodal-pipe/library/include/modal_pipe_interfaces.h: 582

# /ci_data/builds/iDWDkaXk/0/voxl-public/voxl-sdk/core-libs/libmodal-pipe/library/include/modal_pipe_interfaces.h: 586
for _lib in _libs.values():
    if not _lib.has("pipe_point_cloud_format_to_string", "cdecl"):
        continue
    pipe_point_cloud_format_to_string = _lib.get("pipe_point_cloud_format_to_string", "cdecl")
    pipe_point_cloud_format_to_string.argtypes = [c_int]
    pipe_point_cloud_format_to_string.restype = c_char_p
    break

# /ci_data/builds/iDWDkaXk/0/voxl-public/voxl-sdk/core-libs/libmodal-pipe/library/include/modal_pipe_interfaces.h: 601
for _lib in _libs.values():
    if not _lib.has("pipe_point_cloud_meta_to_size_bytes", "cdecl"):
        continue
    pipe_point_cloud_meta_to_size_bytes = _lib.get("pipe_point_cloud_meta_to_size_bytes", "cdecl")
    pipe_point_cloud_meta_to_size_bytes.argtypes = [point_cloud_metadata_t]
    pipe_point_cloud_meta_to_size_bytes.restype = c_int
    break

# /ci_data/builds/iDWDkaXk/0/voxl-public/voxl-sdk/core-libs/libmodal-pipe/library/include/modal_pipe_interfaces.h: 710
class struct_pose_4dof_t(Structure):
    pass

struct_pose_4dof_t._pack_ = 1
struct_pose_4dof_t.__slots__ = [
    'magic_number',
    'timestamp_ns',
    'p',
    'yaw',
]
struct_pose_4dof_t._fields_ = [
    ('magic_number', uint32_t),
    ('timestamp_ns', c_int64),
    ('p', c_double * int(3)),
    ('yaw', c_double),
]

pose_4dof_t = struct_pose_4dof_t# /ci_data/builds/iDWDkaXk/0/voxl-public/voxl-sdk/core-libs/libmodal-pipe/library/include/modal_pipe_interfaces.h: 710

# /ci_data/builds/iDWDkaXk/0/voxl-public/voxl-sdk/core-libs/libmodal-pipe/library/include/modal_pipe_interfaces.h: 759
for _lib in _libs.values():
    if not _lib.has("pipe_validate_pose_4dof_t", "cdecl"):
        continue
    pipe_validate_pose_4dof_t = _lib.get("pipe_validate_pose_4dof_t", "cdecl")
    pipe_validate_pose_4dof_t.argtypes = [String, c_int, POINTER(c_int)]
    pipe_validate_pose_4dof_t.restype = POINTER(pose_4dof_t)
    break

# /ci_data/builds/iDWDkaXk/0/voxl-public/voxl-sdk/core-libs/libmodal-pipe/library/include/modal_pipe_interfaces.h: 796
class struct_pose_vel_6dof_t(Structure):
    pass

struct_pose_vel_6dof_t._pack_ = 1
struct_pose_vel_6dof_t.__slots__ = [
    'magic_number',
    'timestamp_ns',
    'T_child_wrt_parent',
    'R_child_to_parent',
    'v_child_wrt_parent',
    'w_child_wrt_child',
]
struct_pose_vel_6dof_t._fields_ = [
    ('magic_number', uint32_t),
    ('timestamp_ns', c_int64),
    ('T_child_wrt_parent', c_float * int(3)),
    ('R_child_to_parent', (c_float * int(3)) * int(3)),
    ('v_child_wrt_parent', c_float * int(3)),
    ('w_child_wrt_child', c_float * int(3)),
]

pose_vel_6dof_t = struct_pose_vel_6dof_t# /ci_data/builds/iDWDkaXk/0/voxl-public/voxl-sdk/core-libs/libmodal-pipe/library/include/modal_pipe_interfaces.h: 796

# /ci_data/builds/iDWDkaXk/0/voxl-public/voxl-sdk/core-libs/libmodal-pipe/library/include/modal_pipe_interfaces.h: 845
for _lib in _libs.values():
    if not _lib.has("pipe_validate_pose_vel_6dof_t", "cdecl"):
        continue
    pipe_validate_pose_vel_6dof_t = _lib.get("pipe_validate_pose_vel_6dof_t", "cdecl")
    pipe_validate_pose_vel_6dof_t.argtypes = [String, c_int, POINTER(c_int)]
    pipe_validate_pose_vel_6dof_t.restype = POINTER(pose_vel_6dof_t)
    break

# /ci_data/builds/iDWDkaXk/0/voxl-public/voxl-sdk/core-libs/libmodal-pipe/library/include/modal_pipe_interfaces.h: 1037
class struct_vio_data_t(Structure):
    pass

struct_vio_data_t._pack_ = 1
struct_vio_data_t.__slots__ = [
    'magic_number',
    'quality',
    'timestamp_ns',
    'T_imu_wrt_vio',
    'R_imu_to_vio',
    'pose_covariance',
    'vel_imu_wrt_vio',
    'velocity_covariance',
    'imu_angular_vel',
    'gravity_vector',
    'T_cam_wrt_imu',
    'R_cam_to_imu',
    'error_code',
    'n_feature_points',
    'state',
    'frame',
]
struct_vio_data_t._fields_ = [
    ('magic_number', uint32_t),
    ('quality', c_int32),
    ('timestamp_ns', c_int64),
    ('T_imu_wrt_vio', c_float * int(3)),
    ('R_imu_to_vio', (c_float * int(3)) * int(3)),
    ('pose_covariance', c_float * int(21)),
    ('vel_imu_wrt_vio', c_float * int(3)),
    ('velocity_covariance', c_float * int(21)),
    ('imu_angular_vel', c_float * int(3)),
    ('gravity_vector', c_float * int(3)),
    ('T_cam_wrt_imu', c_float * int(3)),
    ('R_cam_to_imu', (c_float * int(3)) * int(3)),
    ('error_code', uint32_t),
    ('n_feature_points', uint16_t),
    ('state', uint8_t),
    ('frame', uint8_t),
]

vio_data_t = struct_vio_data_t# /ci_data/builds/iDWDkaXk/0/voxl-public/voxl-sdk/core-libs/libmodal-pipe/library/include/modal_pipe_interfaces.h: 1037

# /ci_data/builds/iDWDkaXk/0/voxl-public/voxl-sdk/core-libs/libmodal-pipe/library/include/modal_pipe_interfaces.h: 1086
for _lib in _libs.values():
    if not _lib.has("pipe_validate_vio_data_t", "cdecl"):
        continue
    pipe_validate_vio_data_t = _lib.get("pipe_validate_vio_data_t", "cdecl")
    pipe_validate_vio_data_t.argtypes = [String, c_int, POINTER(c_int)]
    pipe_validate_vio_data_t.restype = POINTER(vio_data_t)
    break

enum_vio_point_quality_t = c_int# /ci_data/builds/iDWDkaXk/0/voxl-public/voxl-sdk/core-libs/libmodal-pipe/library/include/modal_pipe_interfaces.h: 1098

LOW = 0# /ci_data/builds/iDWDkaXk/0/voxl-public/voxl-sdk/core-libs/libmodal-pipe/library/include/modal_pipe_interfaces.h: 1098

MEDIUM = (LOW + 1)# /ci_data/builds/iDWDkaXk/0/voxl-public/voxl-sdk/core-libs/libmodal-pipe/library/include/modal_pipe_interfaces.h: 1098

HIGH = (MEDIUM + 1)# /ci_data/builds/iDWDkaXk/0/voxl-public/voxl-sdk/core-libs/libmodal-pipe/library/include/modal_pipe_interfaces.h: 1098

vio_point_quality_t = enum_vio_point_quality_t# /ci_data/builds/iDWDkaXk/0/voxl-public/voxl-sdk/core-libs/libmodal-pipe/library/include/modal_pipe_interfaces.h: 1098

# /ci_data/builds/iDWDkaXk/0/voxl-public/voxl-sdk/core-libs/libmodal-pipe/library/include/modal_pipe_interfaces.h: 1110
class struct_vio_feature_t(Structure):
    pass

struct_vio_feature_t._pack_ = 1
struct_vio_feature_t.__slots__ = [
    'id',
    'cam_id',
    'pix_loc',
    'tsf',
    'p_tsf',
    'depth',
    'depth_error_stddev',
    'point_quality',
]
struct_vio_feature_t._fields_ = [
    ('id', uint32_t),
    ('cam_id', c_int32),
    ('pix_loc', c_float * int(2)),
    ('tsf', c_float * int(3)),
    ('p_tsf', (c_float * int(3)) * int(3)),
    ('depth', c_float),
    ('depth_error_stddev', c_float),
    ('point_quality', vio_point_quality_t),
]

vio_feature_t = struct_vio_feature_t# /ci_data/builds/iDWDkaXk/0/voxl-public/voxl-sdk/core-libs/libmodal-pipe/library/include/modal_pipe_interfaces.h: 1110

# /ci_data/builds/iDWDkaXk/0/voxl-public/voxl-sdk/core-libs/libmodal-pipe/library/include/modal_pipe_interfaces.h: 1129
class struct_ext_vio_data_t(Structure):
    pass

struct_ext_vio_data_t._pack_ = 1
struct_ext_vio_data_t.__slots__ = [
    'v',
    'last_cam_frame_id',
    'last_cam_timestamp_ns',
    'imu_cam_time_shift_s',
    'gravity_covariance',
    'gyro_bias',
    'accl_bias',
    'n_total_features',
    'features',
]
struct_ext_vio_data_t._fields_ = [
    ('v', vio_data_t),
    ('last_cam_frame_id', c_int32),
    ('last_cam_timestamp_ns', c_int64),
    ('imu_cam_time_shift_s', c_float),
    ('gravity_covariance', (c_float * int(3)) * int(3)),
    ('gyro_bias', c_float * int(3)),
    ('accl_bias', c_float * int(3)),
    ('n_total_features', uint32_t),
    ('features', vio_feature_t * int(64)),
]

ext_vio_data_t = struct_ext_vio_data_t# /ci_data/builds/iDWDkaXk/0/voxl-public/voxl-sdk/core-libs/libmodal-pipe/library/include/modal_pipe_interfaces.h: 1129

# /ci_data/builds/iDWDkaXk/0/voxl-public/voxl-sdk/core-libs/libmodal-pipe/library/include/modal_pipe_interfaces.h: 1163
for _lib in _libs.values():
    if not _lib.has("pipe_validate_ext_vio_data_t", "cdecl"):
        continue
    pipe_validate_ext_vio_data_t = _lib.get("pipe_validate_ext_vio_data_t", "cdecl")
    pipe_validate_ext_vio_data_t.argtypes = [String, c_int, POINTER(c_int)]
    pipe_validate_ext_vio_data_t.restype = POINTER(ext_vio_data_t)
    break

# /ci_data/builds/iDWDkaXk/0/voxl-public/voxl-sdk/core-libs/libmodal-pipe/library/include/modal_pipe_interfaces.h: 1172
for _lib in _libs.values():
    if not _lib.has("pipe_print_vio_state", "cdecl"):
        continue
    pipe_print_vio_state = _lib.get("pipe_print_vio_state", "cdecl")
    pipe_print_vio_state.argtypes = [c_int]
    pipe_print_vio_state.restype = None
    break

# /ci_data/builds/iDWDkaXk/0/voxl-public/voxl-sdk/core-libs/libmodal-pipe/library/include/modal_pipe_interfaces.h: 1181
for _lib in _libs.values():
    if not _lib.has("pipe_print_vio_error", "cdecl"):
        continue
    pipe_print_vio_error = _lib.get("pipe_print_vio_error", "cdecl")
    pipe_print_vio_error.argtypes = [uint32_t]
    pipe_print_vio_error.restype = None
    break

# /ci_data/builds/iDWDkaXk/0/voxl-public/voxl-sdk/core-libs/libmodal-pipe/library/include/modal_pipe_interfaces.h: 1200
for _lib in _libs.values():
    if not _lib.has("pipe_construct_vio_error_string", "cdecl"):
        continue
    pipe_construct_vio_error_string = _lib.get("pipe_construct_vio_error_string", "cdecl")
    pipe_construct_vio_error_string.argtypes = [uint32_t, String, c_size_t]
    pipe_construct_vio_error_string.restype = c_int
    break

# /ci_data/builds/iDWDkaXk/0/voxl-public/voxl-sdk/core-libs/libmodal-pipe/library/include/modal_pipe_interfaces.h: 1227
class struct_vfc_data_t(Structure):
    pass

struct_vfc_data_t._pack_ = 1
struct_vfc_data_t.__slots__ = [
    'magic_number',
    'altitude_ok',
    'flow_ok',
    'position_ok',
    'backtrack_seconds',
]
struct_vfc_data_t._fields_ = [
    ('magic_number', uint32_t),
    ('altitude_ok', c_bool),
    ('flow_ok', c_bool),
    ('position_ok', c_bool),
    ('backtrack_seconds', c_float),
]

vfc_data_t = struct_vfc_data_t# /ci_data/builds/iDWDkaXk/0/voxl-public/voxl-sdk/core-libs/libmodal-pipe/library/include/modal_pipe_interfaces.h: 1227

# /ci_data/builds/iDWDkaXk/0/voxl-public/voxl-sdk/core-libs/libmodal-pipe/library/include/modal_pipe_interfaces.h: 1263
for _lib in _libs.values():
    if not _lib.has("pipe_validate_vfc_data_t", "cdecl"):
        continue
    pipe_validate_vfc_data_t = _lib.get("pipe_validate_vfc_data_t", "cdecl")
    pipe_validate_vfc_data_t.argtypes = [String, c_int, POINTER(c_int)]
    pipe_validate_vfc_data_t.restype = POINTER(vfc_data_t)
    break

# <built-in>
try:
    __FLT_MIN__ = 1.17549435082228750796873653722224568e-38
except:
    pass

# /usr/lib/gcc/x86_64-linux-gnu/9/include/float.h: 121
try:
    FLT_MIN = __FLT_MIN__
except:
    pass

# /ci_data/builds/iDWDkaXk/0/voxl-public/voxl-sdk/core-libs/libmodal-pipe/library/include/modal_pipe_interfaces.h: 48
try:
    TAG_DETECTION_MAGIC_NUMBER = 0x564F584C
except:
    pass

# /ci_data/builds/iDWDkaXk/0/voxl-public/voxl-sdk/core-libs/libmodal-pipe/library/include/modal_pipe_interfaces.h: 70
try:
    N_TAG_LOCATION_TYPES = 4
except:
    pass

# /ci_data/builds/iDWDkaXk/0/voxl-public/voxl-sdk/core-libs/libmodal-pipe/library/include/modal_pipe_interfaces.h: 72
try:
    TAG_LOCATION_UNKNOWN = 0
except:
    pass

# /ci_data/builds/iDWDkaXk/0/voxl-public/voxl-sdk/core-libs/libmodal-pipe/library/include/modal_pipe_interfaces.h: 73
try:
    TAG_LOCATION_FIXED = 1
except:
    pass

# /ci_data/builds/iDWDkaXk/0/voxl-public/voxl-sdk/core-libs/libmodal-pipe/library/include/modal_pipe_interfaces.h: 74
try:
    TAG_LOCATION_STATIC = 2
except:
    pass

# /ci_data/builds/iDWDkaXk/0/voxl-public/voxl-sdk/core-libs/libmodal-pipe/library/include/modal_pipe_interfaces.h: 75
try:
    TAG_LOCATION_DYNAMIC = 3
except:
    pass

# /ci_data/builds/iDWDkaXk/0/voxl-public/voxl-sdk/core-libs/libmodal-pipe/library/include/modal_pipe_interfaces.h: 78
try:
    TAG_NAME_LEN = 64
except:
    pass

# /ci_data/builds/iDWDkaXk/0/voxl-public/voxl-sdk/core-libs/libmodal-pipe/library/include/modal_pipe_interfaces.h: 113
try:
    TAG_DETECTION_RECOMMENDED_READ_BUF_SIZE = (sizeof(tag_detection_t) * 16)
except:
    pass

# /ci_data/builds/iDWDkaXk/0/voxl-public/voxl-sdk/core-libs/libmodal-pipe/library/include/modal_pipe_interfaces.h: 121
try:
    TAG_DETECTION_RECOMMENDED_PIPE_SIZE = (64 * 1024)
except:
    pass

# /ci_data/builds/iDWDkaXk/0/voxl-public/voxl-sdk/core-libs/libmodal-pipe/library/include/modal_pipe_interfaces.h: 172
try:
    CAMERA_MAGIC_NUMBER = 0x564F584C
except:
    pass

# /ci_data/builds/iDWDkaXk/0/voxl-public/voxl-sdk/core-libs/libmodal-pipe/library/include/modal_pipe_interfaces.h: 178
try:
    IMAGE_FORMAT_RAW8 = 0
except:
    pass

# /ci_data/builds/iDWDkaXk/0/voxl-public/voxl-sdk/core-libs/libmodal-pipe/library/include/modal_pipe_interfaces.h: 179
try:
    IMAGE_FORMAT_NV12 = 1
except:
    pass

# /ci_data/builds/iDWDkaXk/0/voxl-public/voxl-sdk/core-libs/libmodal-pipe/library/include/modal_pipe_interfaces.h: 180
try:
    IMAGE_FORMAT_STEREO_RAW8 = 2
except:
    pass

# /ci_data/builds/iDWDkaXk/0/voxl-public/voxl-sdk/core-libs/libmodal-pipe/library/include/modal_pipe_interfaces.h: 181
try:
    IMAGE_FORMAT_H264 = 3
except:
    pass

# /ci_data/builds/iDWDkaXk/0/voxl-public/voxl-sdk/core-libs/libmodal-pipe/library/include/modal_pipe_interfaces.h: 182
try:
    IMAGE_FORMAT_H265 = 4
except:
    pass

# /ci_data/builds/iDWDkaXk/0/voxl-public/voxl-sdk/core-libs/libmodal-pipe/library/include/modal_pipe_interfaces.h: 183
try:
    IMAGE_FORMAT_RAW16 = 5
except:
    pass

# /ci_data/builds/iDWDkaXk/0/voxl-public/voxl-sdk/core-libs/libmodal-pipe/library/include/modal_pipe_interfaces.h: 184
try:
    IMAGE_FORMAT_NV21 = 6
except:
    pass

# /ci_data/builds/iDWDkaXk/0/voxl-public/voxl-sdk/core-libs/libmodal-pipe/library/include/modal_pipe_interfaces.h: 185
try:
    IMAGE_FORMAT_JPG = 7
except:
    pass

# /ci_data/builds/iDWDkaXk/0/voxl-public/voxl-sdk/core-libs/libmodal-pipe/library/include/modal_pipe_interfaces.h: 186
try:
    IMAGE_FORMAT_YUV422 = 8
except:
    pass

# /ci_data/builds/iDWDkaXk/0/voxl-public/voxl-sdk/core-libs/libmodal-pipe/library/include/modal_pipe_interfaces.h: 187
try:
    IMAGE_FORMAT_YUV420 = 9
except:
    pass

# /ci_data/builds/iDWDkaXk/0/voxl-public/voxl-sdk/core-libs/libmodal-pipe/library/include/modal_pipe_interfaces.h: 188
try:
    IMAGE_FORMAT_RGB = 10
except:
    pass

# /ci_data/builds/iDWDkaXk/0/voxl-public/voxl-sdk/core-libs/libmodal-pipe/library/include/modal_pipe_interfaces.h: 189
try:
    IMAGE_FORMAT_FLOAT32 = 11
except:
    pass

# /ci_data/builds/iDWDkaXk/0/voxl-public/voxl-sdk/core-libs/libmodal-pipe/library/include/modal_pipe_interfaces.h: 190
try:
    IMAGE_FORMAT_STEREO_NV21 = 12
except:
    pass

# /ci_data/builds/iDWDkaXk/0/voxl-public/voxl-sdk/core-libs/libmodal-pipe/library/include/modal_pipe_interfaces.h: 191
try:
    IMAGE_FORMAT_STEREO_RGB = 13
except:
    pass

# /ci_data/builds/iDWDkaXk/0/voxl-public/voxl-sdk/core-libs/libmodal-pipe/library/include/modal_pipe_interfaces.h: 192
try:
    IMAGE_FORMAT_YUV422_UYVY = 14
except:
    pass

# /ci_data/builds/iDWDkaXk/0/voxl-public/voxl-sdk/core-libs/libmodal-pipe/library/include/modal_pipe_interfaces.h: 193
try:
    IMAGE_FORMAT_STEREO_NV12 = 15
except:
    pass

# /ci_data/builds/iDWDkaXk/0/voxl-public/voxl-sdk/core-libs/libmodal-pipe/library/include/modal_pipe_interfaces.h: 194
try:
    IMAGE_FORMAT_RAW10 = 16
except:
    pass

# /ci_data/builds/iDWDkaXk/0/voxl-public/voxl-sdk/core-libs/libmodal-pipe/library/include/modal_pipe_interfaces.h: 195
try:
    IMAGE_FORMAT_RAW12 = 17
except:
    pass

# /ci_data/builds/iDWDkaXk/0/voxl-public/voxl-sdk/core-libs/libmodal-pipe/library/include/modal_pipe_interfaces.h: 298
try:
    TOF_MAGIC_NUMBER = 0x564F584C
except:
    pass

# /ci_data/builds/iDWDkaXk/0/voxl-public/voxl-sdk/core-libs/libmodal-pipe/library/include/modal_pipe_interfaces.h: 300
try:
    MPA_TOF_WIDTH = 224
except:
    pass

# /ci_data/builds/iDWDkaXk/0/voxl-public/voxl-sdk/core-libs/libmodal-pipe/library/include/modal_pipe_interfaces.h: 301
try:
    MPA_TOF_HEIGHT = 172
except:
    pass

# /ci_data/builds/iDWDkaXk/0/voxl-public/voxl-sdk/core-libs/libmodal-pipe/library/include/modal_pipe_interfaces.h: 302
try:
    MPA_TOF_SIZE = (MPA_TOF_WIDTH * MPA_TOF_HEIGHT)
except:
    pass

# /ci_data/builds/iDWDkaXk/0/voxl-public/voxl-sdk/core-libs/libmodal-pipe/library/include/modal_pipe_interfaces.h: 325
try:
    TOF_RECOMMENDED_READ_BUF_SIZE = (sizeof(tof_data_t) * 4)
except:
    pass

# /ci_data/builds/iDWDkaXk/0/voxl-public/voxl-sdk/core-libs/libmodal-pipe/library/include/modal_pipe_interfaces.h: 332
try:
    TOF_RECOMMENDED_PIPE_SIZE = ((1024 * 1024) * 64)
except:
    pass

# /ci_data/builds/iDWDkaXk/0/voxl-public/voxl-sdk/core-libs/libmodal-pipe/library/include/modal_pipe_interfaces.h: 378
try:
    TOF2_MAGIC_NUMBER = (0x564F584C + 1)
except:
    pass

# /ci_data/builds/iDWDkaXk/0/voxl-public/voxl-sdk/core-libs/libmodal-pipe/library/include/modal_pipe_interfaces.h: 380
try:
    MPA_MAX_TOF2_WIDTH = 240
except:
    pass

# /ci_data/builds/iDWDkaXk/0/voxl-public/voxl-sdk/core-libs/libmodal-pipe/library/include/modal_pipe_interfaces.h: 381
try:
    MPA_MAX_TOF2_HEIGHT = 180
except:
    pass

# /ci_data/builds/iDWDkaXk/0/voxl-public/voxl-sdk/core-libs/libmodal-pipe/library/include/modal_pipe_interfaces.h: 382
try:
    MPA_MAX_TOF2_SIZE = (MPA_MAX_TOF2_WIDTH * MPA_MAX_TOF2_HEIGHT)
except:
    pass

# /ci_data/builds/iDWDkaXk/0/voxl-public/voxl-sdk/core-libs/libmodal-pipe/library/include/modal_pipe_interfaces.h: 414
try:
    TOF2_RECOMMENDED_READ_BUF_SIZE = (sizeof(tof2_data_t) * 4)
except:
    pass

# /ci_data/builds/iDWDkaXk/0/voxl-public/voxl-sdk/core-libs/libmodal-pipe/library/include/modal_pipe_interfaces.h: 421
try:
    TOF2_RECOMMENDED_PIPE_SIZE = ((1024 * 1024) * 64)
except:
    pass

# /ci_data/builds/iDWDkaXk/0/voxl-public/voxl-sdk/core-libs/libmodal-pipe/library/include/modal_pipe_interfaces.h: 463
try:
    IMU_MAGIC_NUMBER = 0x564F584C
except:
    pass

# /ci_data/builds/iDWDkaXk/0/voxl-public/voxl-sdk/core-libs/libmodal-pipe/library/include/modal_pipe_interfaces.h: 471
try:
    IMU_INVALID_TEMPERATURE_VALUE = FLT_MIN
except:
    pass

# /ci_data/builds/iDWDkaXk/0/voxl-public/voxl-sdk/core-libs/libmodal-pipe/library/include/modal_pipe_interfaces.h: 499
try:
    IMU_RECOMMENDED_READ_BUF_SIZE = (sizeof(imu_data_t) * 400)
except:
    pass

# /ci_data/builds/iDWDkaXk/0/voxl-public/voxl-sdk/core-libs/libmodal-pipe/library/include/modal_pipe_interfaces.h: 507
try:
    IMU_RECOMMENDED_PIPE_SIZE = (128 * 1024)
except:
    pass

# /ci_data/builds/iDWDkaXk/0/voxl-public/voxl-sdk/core-libs/libmodal-pipe/library/include/modal_pipe_interfaces.h: 564
try:
    POINT_CLOUD_MAGIC_NUMBER = 0x564F584C
except:
    pass

# /ci_data/builds/iDWDkaXk/0/voxl-public/voxl-sdk/core-libs/libmodal-pipe/library/include/modal_pipe_interfaces.h: 566
try:
    POINT_CLOUD_FORMAT_FLOAT_XYZ = 0
except:
    pass

# /ci_data/builds/iDWDkaXk/0/voxl-public/voxl-sdk/core-libs/libmodal-pipe/library/include/modal_pipe_interfaces.h: 567
try:
    POINT_CLOUD_FORMAT_FLOAT_XYZC = 1
except:
    pass

# /ci_data/builds/iDWDkaXk/0/voxl-public/voxl-sdk/core-libs/libmodal-pipe/library/include/modal_pipe_interfaces.h: 568
try:
    POINT_CLOUD_FORMAT_FLOAT_XYZRGB = 2
except:
    pass

# /ci_data/builds/iDWDkaXk/0/voxl-public/voxl-sdk/core-libs/libmodal-pipe/library/include/modal_pipe_interfaces.h: 569
try:
    POINT_CLOUD_FORMAT_FLOAT_XYZCRGB = 3
except:
    pass

# /ci_data/builds/iDWDkaXk/0/voxl-public/voxl-sdk/core-libs/libmodal-pipe/library/include/modal_pipe_interfaces.h: 570
try:
    POINT_CLOUD_FORMAT_FLOAT_XY = 4
except:
    pass

# /ci_data/builds/iDWDkaXk/0/voxl-public/voxl-sdk/core-libs/libmodal-pipe/library/include/modal_pipe_interfaces.h: 571
try:
    POINT_CLOUD_FORMAT_FLOAT_XYC = 5
except:
    pass

# /ci_data/builds/iDWDkaXk/0/voxl-public/voxl-sdk/core-libs/libmodal-pipe/library/include/modal_pipe_interfaces.h: 685
try:
    POSE_4DOF_MAGIC_NUMBER = 0x564F584C
except:
    pass

# /ci_data/builds/iDWDkaXk/0/voxl-public/voxl-sdk/core-libs/libmodal-pipe/library/include/modal_pipe_interfaces.h: 724
try:
    POSE_4DOF_RECOMMENDED_READ_BUF_SIZE = (sizeof(pose_4dof_t) * 23)
except:
    pass

# /ci_data/builds/iDWDkaXk/0/voxl-public/voxl-sdk/core-libs/libmodal-pipe/library/include/modal_pipe_interfaces.h: 733
try:
    POSE_4DOF_RECOMMENDED_PIPE_SIZE = (64 * 1024)
except:
    pass

# /ci_data/builds/iDWDkaXk/0/voxl-public/voxl-sdk/core-libs/libmodal-pipe/library/include/modal_pipe_interfaces.h: 778
try:
    POSE_VEL_6DOF_MAGIC_NUMBER = 0x564F584C
except:
    pass

# /ci_data/builds/iDWDkaXk/0/voxl-public/voxl-sdk/core-libs/libmodal-pipe/library/include/modal_pipe_interfaces.h: 810
try:
    POSE_6DOF_RECOMMENDED_READ_BUF_SIZE = (sizeof(pose_vel_6dof_t) * 24)
except:
    pass

# /ci_data/builds/iDWDkaXk/0/voxl-public/voxl-sdk/core-libs/libmodal-pipe/library/include/modal_pipe_interfaces.h: 819
try:
    POSE_6DOF_RECOMMENDED_PIPE_SIZE = (64 * 1024)
except:
    pass

# /ci_data/builds/iDWDkaXk/0/voxl-public/voxl-sdk/core-libs/libmodal-pipe/library/include/modal_pipe_interfaces.h: 921
try:
    VIO_STATE_FAILED = 0
except:
    pass

# /ci_data/builds/iDWDkaXk/0/voxl-public/voxl-sdk/core-libs/libmodal-pipe/library/include/modal_pipe_interfaces.h: 922
try:
    VIO_STATE_INITIALIZING = 1
except:
    pass

# /ci_data/builds/iDWDkaXk/0/voxl-public/voxl-sdk/core-libs/libmodal-pipe/library/include/modal_pipe_interfaces.h: 923
try:
    VIO_STATE_OK = 2
except:
    pass

# /ci_data/builds/iDWDkaXk/0/voxl-public/voxl-sdk/core-libs/libmodal-pipe/library/include/modal_pipe_interfaces.h: 926
try:
    ERROR_CODE_COVARIANCE = (1 << 0)
except:
    pass

# /ci_data/builds/iDWDkaXk/0/voxl-public/voxl-sdk/core-libs/libmodal-pipe/library/include/modal_pipe_interfaces.h: 927
try:
    ERROR_CODE_IMU_OOB = (1 << 1)
except:
    pass

# /ci_data/builds/iDWDkaXk/0/voxl-public/voxl-sdk/core-libs/libmodal-pipe/library/include/modal_pipe_interfaces.h: 928
try:
    ERROR_CODE_IMU_BW = (1 << 2)
except:
    pass

# /ci_data/builds/iDWDkaXk/0/voxl-public/voxl-sdk/core-libs/libmodal-pipe/library/include/modal_pipe_interfaces.h: 929
try:
    ERROR_CODE_NOT_STATIONARY = (1 << 3)
except:
    pass

# /ci_data/builds/iDWDkaXk/0/voxl-public/voxl-sdk/core-libs/libmodal-pipe/library/include/modal_pipe_interfaces.h: 930
try:
    ERROR_CODE_NO_FEATURES = (1 << 4)
except:
    pass

# /ci_data/builds/iDWDkaXk/0/voxl-public/voxl-sdk/core-libs/libmodal-pipe/library/include/modal_pipe_interfaces.h: 931
try:
    ERROR_CODE_CONSTRAINT = (1 << 5)
except:
    pass

# /ci_data/builds/iDWDkaXk/0/voxl-public/voxl-sdk/core-libs/libmodal-pipe/library/include/modal_pipe_interfaces.h: 932
try:
    ERROR_CODE_FEATURE_ADD = (1 << 6)
except:
    pass

# /ci_data/builds/iDWDkaXk/0/voxl-public/voxl-sdk/core-libs/libmodal-pipe/library/include/modal_pipe_interfaces.h: 933
try:
    ERROR_CODE_VEL_INST_CERT = (1 << 7)
except:
    pass

# /ci_data/builds/iDWDkaXk/0/voxl-public/voxl-sdk/core-libs/libmodal-pipe/library/include/modal_pipe_interfaces.h: 934
try:
    ERROR_CODE_VEL_WINDOW_CERT = (1 << 8)
except:
    pass

# /ci_data/builds/iDWDkaXk/0/voxl-public/voxl-sdk/core-libs/libmodal-pipe/library/include/modal_pipe_interfaces.h: 935
try:
    ERROR_CODE_DROPPED_IMU = (1 << 10)
except:
    pass

# /ci_data/builds/iDWDkaXk/0/voxl-public/voxl-sdk/core-libs/libmodal-pipe/library/include/modal_pipe_interfaces.h: 936
try:
    ERROR_CODE_BAD_CAM_CAL = (1 << 11)
except:
    pass

# /ci_data/builds/iDWDkaXk/0/voxl-public/voxl-sdk/core-libs/libmodal-pipe/library/include/modal_pipe_interfaces.h: 937
try:
    ERROR_CODE_LOW_FEATURES = (1 << 12)
except:
    pass

# /ci_data/builds/iDWDkaXk/0/voxl-public/voxl-sdk/core-libs/libmodal-pipe/library/include/modal_pipe_interfaces.h: 938
try:
    ERROR_CODE_DROPPED_CAM = (1 << 13)
except:
    pass

# /ci_data/builds/iDWDkaXk/0/voxl-public/voxl-sdk/core-libs/libmodal-pipe/library/include/modal_pipe_interfaces.h: 939
try:
    ERROR_CODE_DROPPED_GPS_VEL = (1 << 14)
except:
    pass

# /ci_data/builds/iDWDkaXk/0/voxl-public/voxl-sdk/core-libs/libmodal-pipe/library/include/modal_pipe_interfaces.h: 940
try:
    ERROR_CODE_BAD_TIMESTAMP = (1 << 15)
except:
    pass

# /ci_data/builds/iDWDkaXk/0/voxl-public/voxl-sdk/core-libs/libmodal-pipe/library/include/modal_pipe_interfaces.h: 941
try:
    ERROR_CODE_IMU_MISSING = (1 << 16)
except:
    pass

# /ci_data/builds/iDWDkaXk/0/voxl-public/voxl-sdk/core-libs/libmodal-pipe/library/include/modal_pipe_interfaces.h: 942
try:
    ERROR_CODE_CAM_MISSING = (1 << 17)
except:
    pass

# /ci_data/builds/iDWDkaXk/0/voxl-public/voxl-sdk/core-libs/libmodal-pipe/library/include/modal_pipe_interfaces.h: 943
try:
    ERROR_CODE_CAM_BAD_RES = (1 << 18)
except:
    pass

# /ci_data/builds/iDWDkaXk/0/voxl-public/voxl-sdk/core-libs/libmodal-pipe/library/include/modal_pipe_interfaces.h: 944
try:
    ERROR_CODE_CAM_BAD_FORMAT = (1 << 19)
except:
    pass

# /ci_data/builds/iDWDkaXk/0/voxl-public/voxl-sdk/core-libs/libmodal-pipe/library/include/modal_pipe_interfaces.h: 945
try:
    ERROR_CODE_UNKNOWN = (1 << 20)
except:
    pass

# /ci_data/builds/iDWDkaXk/0/voxl-public/voxl-sdk/core-libs/libmodal-pipe/library/include/modal_pipe_interfaces.h: 946
try:
    ERROR_CODE_STALLED = (1 << 21)
except:
    pass

# /ci_data/builds/iDWDkaXk/0/voxl-public/voxl-sdk/core-libs/libmodal-pipe/library/include/modal_pipe_interfaces.h: 967
try:
    VIO_FRAME_UNKNOWN = 0
except:
    pass

# /ci_data/builds/iDWDkaXk/0/voxl-public/voxl-sdk/core-libs/libmodal-pipe/library/include/modal_pipe_interfaces.h: 968
try:
    VIO_FRAME_IMU_UNALIGNED = 1
except:
    pass

# /ci_data/builds/iDWDkaXk/0/voxl-public/voxl-sdk/core-libs/libmodal-pipe/library/include/modal_pipe_interfaces.h: 969
try:
    VIO_FRAME_BODY_ALIGNED = 2
except:
    pass

# /ci_data/builds/iDWDkaXk/0/voxl-public/voxl-sdk/core-libs/libmodal-pipe/library/include/modal_pipe_interfaces.h: 983
try:
    RESET_VIO_SOFT = 'reset_vio_soft'
except:
    pass

# /ci_data/builds/iDWDkaXk/0/voxl-public/voxl-sdk/core-libs/libmodal-pipe/library/include/modal_pipe_interfaces.h: 984
try:
    RESET_VIO_HARD = 'reset_vio_hard'
except:
    pass

# /ci_data/builds/iDWDkaXk/0/voxl-public/voxl-sdk/core-libs/libmodal-pipe/library/include/modal_pipe_interfaces.h: 994
try:
    VIO_MAGIC_NUMBER = 0x5455524
except:
    pass

# /ci_data/builds/iDWDkaXk/0/voxl-public/voxl-sdk/core-libs/libmodal-pipe/library/include/modal_pipe_interfaces.h: 1051
try:
    VIO_RECOMMENDED_READ_BUF_SIZE = (sizeof(vio_data_t) * 26)
except:
    pass

# /ci_data/builds/iDWDkaXk/0/voxl-public/voxl-sdk/core-libs/libmodal-pipe/library/include/modal_pipe_interfaces.h: 1060
try:
    VIO_RECOMMENDED_PIPE_SIZE = (64 * 1024)
except:
    pass

# /ci_data/builds/iDWDkaXk/0/voxl-public/voxl-sdk/core-libs/libmodal-pipe/library/include/modal_pipe_interfaces.h: 1091
try:
    VIO_MAX_REPORTED_FEATURES = 64
except:
    pass

# /ci_data/builds/iDWDkaXk/0/voxl-public/voxl-sdk/core-libs/libmodal-pipe/library/include/modal_pipe_interfaces.h: 1137
try:
    EXT_VIO_RECOMMENDED_READ_BUF_SIZE = (sizeof(ext_vio_data_t) * 10)
except:
    pass

# /ci_data/builds/iDWDkaXk/0/voxl-public/voxl-sdk/core-libs/libmodal-pipe/library/include/modal_pipe_interfaces.h: 1214
try:
    VFC_MAGIC_NUMBER = 0x5455525
except:
    pass

# /ci_data/builds/iDWDkaXk/0/voxl-public/voxl-sdk/core-libs/libmodal-pipe/library/include/modal_pipe_interfaces.h: 1238
try:
    VFC_RECOMMENDED_READ_BUF_SIZE = (sizeof(vfc_data_t) * 32)
except:
    pass

tag_detection_t = struct_tag_detection_t# /ci_data/builds/iDWDkaXk/0/voxl-public/voxl-sdk/core-libs/libmodal-pipe/library/include/modal_pipe_interfaces.h: 100

camera_image_metadata_t = struct_camera_image_metadata_t# /ci_data/builds/iDWDkaXk/0/voxl-public/voxl-sdk/core-libs/libmodal-pipe/library/include/modal_pipe_interfaces.h: 216

tof_data_t = struct_tof_data_t# /ci_data/builds/iDWDkaXk/0/voxl-public/voxl-sdk/core-libs/libmodal-pipe/library/include/modal_pipe_interfaces.h: 311

tof2_data_t = struct_tof2_data_t# /ci_data/builds/iDWDkaXk/0/voxl-public/voxl-sdk/core-libs/libmodal-pipe/library/include/modal_pipe_interfaces.h: 400

imu_data_t = struct_imu_data_t# /ci_data/builds/iDWDkaXk/0/voxl-public/voxl-sdk/core-libs/libmodal-pipe/library/include/modal_pipe_interfaces.h: 484

point_cloud_metadata_t = struct_point_cloud_metadata_t# /ci_data/builds/iDWDkaXk/0/voxl-public/voxl-sdk/core-libs/libmodal-pipe/library/include/modal_pipe_interfaces.h: 582

pose_4dof_t = struct_pose_4dof_t# /ci_data/builds/iDWDkaXk/0/voxl-public/voxl-sdk/core-libs/libmodal-pipe/library/include/modal_pipe_interfaces.h: 710

pose_vel_6dof_t = struct_pose_vel_6dof_t# /ci_data/builds/iDWDkaXk/0/voxl-public/voxl-sdk/core-libs/libmodal-pipe/library/include/modal_pipe_interfaces.h: 796

vio_data_t = struct_vio_data_t# /ci_data/builds/iDWDkaXk/0/voxl-public/voxl-sdk/core-libs/libmodal-pipe/library/include/modal_pipe_interfaces.h: 1037

vio_feature_t = struct_vio_feature_t# /ci_data/builds/iDWDkaXk/0/voxl-public/voxl-sdk/core-libs/libmodal-pipe/library/include/modal_pipe_interfaces.h: 1110

ext_vio_data_t = struct_ext_vio_data_t# /ci_data/builds/iDWDkaXk/0/voxl-public/voxl-sdk/core-libs/libmodal-pipe/library/include/modal_pipe_interfaces.h: 1129

vfc_data_t = struct_vfc_data_t# /ci_data/builds/iDWDkaXk/0/voxl-public/voxl-sdk/core-libs/libmodal-pipe/library/include/modal_pipe_interfaces.h: 1227

# No inserted files

# No prefix-stripping

